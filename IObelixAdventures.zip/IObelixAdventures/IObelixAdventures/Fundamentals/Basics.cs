﻿using System.IO;

namespace IObelixAdventures.Fundamentals
{
    public class Basics
    {
        public static bool CheckExistence(string filePath)
        {
            if (string.IsNullOrEmpty(filePath))// string nulle ou pas 

                return false; // return it 

            return File.Exists(filePath) || Directory.Exists(filePath);// look at if this exists or not 
        }
        
    }
}