﻿using System;

namespace IObelixAdventures
{
  internal class Program
  {
    public static void Main(string[] args)
    {
      bool a1 = Fundamentals.Basics.CheckExistence("Papernoramix");    // a1 == true
      bool a2 = Fundamentals.Basics.CheckExistence("CaiusOptus");      // a2 == false
      bool a3 = Fundamentals.Basics.CheckExistence("Desk");            // a3 == false
      bool a4 = Fundamentals.Basics.CheckExistence("");                // a4 == false
      Console.WriteLine(a1);
      Console.WriteLine(a2);
      Console.WriteLine(a3);
      Console.WriteLine(a4);
      
      
    }
  }
}